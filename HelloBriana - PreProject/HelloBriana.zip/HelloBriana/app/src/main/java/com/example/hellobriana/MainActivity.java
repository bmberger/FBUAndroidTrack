package com.example.hellobriana;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Edit text - aka change the words to what the user wants
        View editTextButtonView = findViewById(R.id.editTextButton);
        editTextButtonView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView message = ((TextView) findViewById(R.id.textView));
                EditText edit = ((EditText)findViewById(R.id.editText));

                // gets user's inputted text
                String userText = edit.getText().toString();

                // sets the message to the user's inputted text
                if (TextUtils.isEmpty(userText)) {
                    // default if the user enters an empty string
                    message.setText("Hello from Briana");
                } else {
                    message.setText(userText);
                }

                // reset the edit text region to reset back to default message
                edit.setText("");
            }
        });

        // Switch text color button functionality
        View textColorButtonView = findViewById(R.id.textColorButton);
        textColorButtonView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView helloMessage = ((TextView) findViewById(R.id.textView));

                // Allows you to set and reset the hello message color
                if(helloMessage.getCurrentTextColor() == getResources().getColor(R.color.colorAccent)) {
                    helloMessage.setTextColor(getResources().getColor(R.color.colorPrimary));
                } else {
                    helloMessage.setTextColor(getResources().getColor(R.color.colorAccent));
                }
            }
        });

        // Change background image button functionality
        View backgroundButtonView = findViewById(R.id.backgroundButton);
        backgroundButtonView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                View background = findViewById(R.id.rootView);
                background.setBackgroundResource(R.drawable.editedflowers);
            }
        });

        // Reset to original state when clicked
        View backgroundView = findViewById(R.id.rootView);
        backgroundView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                View background = findViewById(R.id.rootView);
                TextView message = ((TextView) findViewById(R.id.textView));

                // reset the text back to 'Hello from Briana'
                message.setText("Hello from Briana");

                // reset the text color back to black
                message.setTextColor(getResources().getColor(R.color.colorAccent));

                // resets the background to original colored flower image
                background.setBackgroundResource(R.drawable.flowers);
            }
        });
    }
}
